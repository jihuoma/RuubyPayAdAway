package com.wovow.ruubypayadaway;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

import com.wovow.ruubypayadaway.utils.Constants;

import org.json.JSONArray;

public class MainHook implements IXposedHookLoadPackage {
    private static final String TAG = "Hook_wovow";

    @Override
    public void handleLoadPackage(final LoadPackageParam lpparam) throws Throwable {

        if (lpparam.packageName.equals(Constants.TARGET_PACKAGE)) {
            debug("----> Found target pkg: " + Constants.TARGET_PACKAGE);

            try {
                XposedHelpers.findAndHookMethod("android.app.Instrumentation", lpparam.classLoader, "newApplication", ClassLoader.class, String.class, Context.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        BlockAds(lpparam);
                    }
                });
            } catch (Throwable t) {
                XposedBridge.log(t);
            }
        }

        if (lpparam.packageName.equals(Constants.GOOGLE_YOUTUBE_XPOSED)) {
            try {
                XposedHelpers.findAndHookMethod(Constants.GOOGLE_YOUTUBE_XPOSED + ".XChecker", lpparam.classLoader,
                        "isEnabled", XC_MethodReplacement.returnConstant(Boolean.TRUE));
            } catch (Throwable t) {
                XposedBridge.log(t);
            }
        }
    }

    private void BlockAds(final LoadPackageParam lpparam) {

        // 禁用启动广告
        try {
            final String className = "enfc.metro.db.DBManager";
            final String methName = "getData";
            final String ad_launch_show_time = "ad_launch_show_time";
            final String ad_launch_interval_time ="ad_launch_interval_time";
            final Class cla = XposedHelpers.findClass(className, lpparam.classLoader);
            if (cla != null) {
                XposedHelpers.findAndHookMethod(cla, methName, String.class, new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        if (ad_launch_show_time.equals(param.args[0]) || ad_launch_interval_time.equals(param.args[0]))
                            param.setResult(new JSONArray("0")); // 设置时间为0，屏蔽广告
                    }
                });

            } else
                debug("Error,can not find [DBManager.getData()]");

        } catch (Throwable e) {
            debug("hook [DBManager.getData()] Throwable: " + e);
        }

        // 打印日志,用于调试
        if (BuildConfig.DEBUG) {
            try {
                final String className = "enfc.metro.ryxlog.Log";
                final Class cla = XposedHelpers.findClass(className, lpparam.classLoader);
                if (cla != null) {
                    XposedHelpers.findAndHookMethod(cla, "add", String.class, String.class, new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
                            debug("Log-Tag:" + param.args[0] + " --> " + param.args[1]);
                        }
                    });
                } else
                    debug("set  enfc.metro.ryxlog.Log.addl() failed");

            } catch (Exception e) {
                e.printStackTrace();
                debug("hook  enfc.metro.ryxlog.Log  Exception:" + e);
            }
        }

        // 禁止使用定位功能：
        try {
            final String className = "com.ruubypay.location.android.RPLocationService";
            XposedHelpers.findAndHookMethod(className, lpparam.classLoader, "internalStartLocation", long.class, XC_MethodReplacement.returnConstant(void.class));
            XposedHelpers.findAndHookMethod(className, lpparam.classLoader, "startUpadtingLocationWithTimeInterval", long.class, XC_MethodReplacement.returnConstant(void.class));
        } catch (Throwable t) {
            XposedBridge.log(t);
        }


        try {
            final String className = "enfc.metro.api.ApiConstants";
            final Class cla = XposedHelpers.findClass(className, lpparam.classLoader);
            if (cla != null) {
                XposedHelpers.findAndHookMethod(cla, "adHost", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) throws Throwable {
                        debug("  --> enfc.metro.api.ApiConstants.adHost=" + param.getResult());
                        param.setResult("http://127.0.0.1");
                    }
                });
            } else
                debug("set adHost failed");

        } catch (Throwable e) {
            debug("hook adHost: " + e);
            e.printStackTrace();
        }


    }


    /*
     * 打印日志
     */
    private void debug(String msg) {
        if (BuildConfig.DEBUG) {
            try {
                Log.d(TAG, msg);
            } catch (Throwable e) {
                Log.e(TAG, "Throwable: " + e.toString());
                e.printStackTrace();
            }
        }
    }

    private static void debug(Throwable msg) {
        if (BuildConfig.DEBUG) {
            XposedBridge.log("Throwable: " + msg);
            Log.e(TAG, "Throwable: " + msg);
        }
    }

}