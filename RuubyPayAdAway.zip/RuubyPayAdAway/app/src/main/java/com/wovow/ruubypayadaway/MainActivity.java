package com.wovow.ruubypayadaway;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.wovow.ruubypayadaway.R.id;

import java.util.Locale;

public class MainActivity extends Activity {
    private final String DONATE_URL = "https://www.paypal.me/wovow/10";
    private String mLang = "zh";
    private static Context mContext;


    //定义一个图片显示控件
    private ImageView imageView;
    private static final int REQUEST_EXTERNAL_STORAGE = 1;
    private static String[] PERMISSIONS_STORAGE = {
            "android.permission.READ_EXTERNAL_STORAGE",
            "android.permission.WRITE_EXTERNAL_STORAGE"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        mContext = this;

        //判断是否6.0以上的手机   不是就不用
        if (Build.VERSION.SDK_INT >= 23) {
            //判断是否有这个权限
            verifyStoragePermissions(this);

        } else {
            // 检测更新
            new UpdateTask(this, true).update();
        }

        mLang = Locale.getDefault().getLanguage();
        Log.d("MainActivity", "getLanguage=" + mLang);

        String pInfo = "";
        try {
            pInfo = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Throwable e) {
            e.printStackTrace();
        }
        Resources res = getResources();
        String status = res.getString(R.string.app_name)

                + " "
                + (XChecker.isEnabled() ? res.getString(R.string.module_active) : res
                .getString(R.string.module_inactive));
        TextView tvStatus = ((TextView) findViewById(R.id.moduleStatus));
        tvStatus.setText(status);
        tvStatus.setTextColor((XChecker.isEnabled() ? Color.GREEN : Color.RED));

        findViewById(id.btnOK).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        findViewById(id.btnDonate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(DONATE_URL));
                    startActivity(browserIntent);
                } catch (Throwable e) {
                    e.printStackTrace();
                } finally {
                    finish();
                }
            }
        });

        findViewById(id.btnDonate_WX).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    imageView = findViewById(R.id.photo);
                    Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.wxqr);
                    imageView.setImageBitmap(bitmap);
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        });

        findViewById(id.btnDonate_ALI).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    imageView = findViewById(R.id.photo);
                    Bitmap bitmap = BitmapFactory.decodeResource(mContext.getResources(), R.drawable.alipayqr);
                    imageView.setImageBitmap(bitmap);
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        });


    }

    /*
     * android 动态权限申请
     * */
    public static void verifyStoragePermissions(Activity activity) {
        try {
            //检测是否有写的权限
            int permission = ActivityCompat.checkSelfPermission(activity, "android.permission.WRITE_EXTERNAL_STORAGE");
            if (permission != PackageManager.PERMISSION_GRANTED) {
                // 没有写的权限，去申请写的权限，会弹出对话框
                ActivityCompat.requestPermissions(activity, PERMISSIONS_STORAGE, REQUEST_EXTERNAL_STORAGE);
            }else {
                // 检测更新
                new UpdateTask(mContext, true).update();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //判断授权的方法  授权成功直接调用写入方法  这是监听的回调
    //参数  上下文   授权结果的数组   申请授权的数组
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_EXTERNAL_STORAGE && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            // 检测更新
            new UpdateTask(this, true).update();
        }

    }

    /**
     * 安装apk
     *
     * @param uri     apk存放的路径
     * @param context
     */
    public static void openApk(Uri uri, Context context) {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_VIEW);
        if (Build.VERSION.SDK_INT >= 24) {
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
        } else {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        intent.setDataAndType(uri, "application/vnd.android.package-archive");
        context.startActivity(intent);
    }


}
