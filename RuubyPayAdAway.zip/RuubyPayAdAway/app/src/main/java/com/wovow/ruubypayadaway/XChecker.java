package com.wovow.ruubypayadaway;

public class XChecker {

    public static boolean isEnabled() {
        return false;
    }
}
