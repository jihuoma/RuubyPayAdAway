package com.wovow.ruubypayadaway.utils;

public class Constants {
    public static final String TARGET_PACKAGE = "enfc.metro";
    public static final String GOOGLE_YOUTUBE_XPOSED = "com.wovow.ruubypayadaway";
    public static final String MAIN_PREFS = "main_prefs";

    /**
     * 360加固
     */
    public static final String QI_HOO =  "com.stub.StubApp" ;
    /**
     * 爱加密
     */
    public static final String AI_JIA_MI =  "s.h.e.l.l.S" ;
    /**
     * 梆梆加固
     */
    public static final String  BANG_BANG = "com.secneo.apkwrapper.ApplicationWrapper";
    /**
     * 腾讯加固
     */
    public static final String  TENCENT =  "com.tencent.StubShell.TxAppEntry" ;
    /**
     * 百度加固
     */
    public static final String  BAI_DU =  "com.baidu.protect.StubApplication" ;

    public static final String[] JIA_GU ={QI_HOO,AI_JIA_MI,BANG_BANG,TENCENT,BAI_DU};

}
