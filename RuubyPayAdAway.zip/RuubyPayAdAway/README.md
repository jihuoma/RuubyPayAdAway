# RuubyPayAdAway
基于Xposed框架的《易通行》app，去广告，禁用定位
